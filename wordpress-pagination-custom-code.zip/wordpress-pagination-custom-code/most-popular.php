
<?php

$max = 10;

if(isset($_GET['pg'])) {
	
	$p = $_GET['pg'];
	
} else {
	
	$p = 1;
	
}

$limit = ($p - 1) * $max;
$prev = $p - 1;
$next = $p + 1;
$limits = (int)($p - 1) * $max;
$totalres = count($wpdb->get_results("SELECT * FROM $wpdb->posts wp INNER JOIN $wpdb->postmeta wpm ON wp.ID = wpm.post_id INNER JOIN $wpdb->term_relationships wpr ON wp.ID = wpr.object_id INNER JOIN $wpdb->terms wpt ON wpr.term_taxonomy_id = wpt.term_id INNER JOIN $wpdb->term_taxonomy wptt ON wptt.term_id = wpr.term_taxonomy_id  WHERE wpt.slug != 'ethnic-news' and wp.post_status='publish' AND wp.post_type = 'post' AND wpm.meta_key='post_view' AND wptt.parent = '0'  group by wp.ID ORDER BY wpm.meta_value DESC"));

//devide it with the max value & round it up
$totalposts = ceil($totalres / $max);
$lpm1 = $totalposts - 1;
$url = site_url().'/most-popular/?page';
$database_url = $wpdb->get_results("SELECT * FROM $wpdb->posts wp INNER JOIN $wpdb->postmeta wpm ON wp.ID = wpm.post_id INNER JOIN $wpdb->term_relationships wpr ON wp.ID = wpr.object_id INNER JOIN $wpdb->terms wpt ON wpr.term_taxonomy_id = wpt.term_id INNER JOIN $wpdb->term_taxonomy wptt ON wptt.term_id = wpr.term_taxonomy_id  WHERE wpt.slug != 'ethnic-news' and wp.post_status='publish' AND wp.post_type = 'post' AND wpm.meta_key='post_view' AND wptt.parent = '0'  group by wp.ID ORDER BY wpm.meta_value DESC limit $limits,$max");

	?>
	<div style="float:right;  margin-bottom: 16px;"> <?php get_ssb(); ?></div>
	<h1 style="margin: 0 0 40px;"><?php the_title(); ?></h1>
	<div class="scrollbar">
	
	<?php
	
	foreach($database_url as $item) {
	?>
	
		<div id="divMain1" class="slickscroll">
			<div class="category" id="category">	       
				<div class="cat_box">
					<p class="cat_img">
						
						<?php 
				
						//$thumbnail_image = get_the_post_thumbnail($item->ID,array(82,81));
						$image_url = wp_get_attachment_url( get_post_thumbnail_id($item->ID) );
						if(!empty($image_url)) {
							?>
							<img style="width:82px; height:110px;" alt="Utsavpedia" class="attachment-small-post-thumbnail wp-post-image" src="<?php echo $image_url; ?>">
							<?php
						} else { ?>
							<img style="width:82px; height:110px;" alt="Utsavpedia" class="attachment-small-post-thumbnail wp-post-image" src="<?php echo get_site_url(); ?>/wp-content/plugins/category-image/images/Draping-style.jpg">
						<?php }	 
						?>
						
						
					</p>
					<div class="content">
						<h2>
							<a href="<?php echo get_permalink( $item->ID ); ?>">
							
								<?php 
								$title_data = $item->post_title;
								$count = strlen($title_data);
								if($count > 60) {
									$check_title 	= substr(strip_tags($title_data),0,60);
									$title_array = explode(" ",$check_title);											
									$array_count = count($title_array);
									$dispay_title = "";
									for($start = 0 ; $start < $array_count-1; $start++) 
									{
										$dispay_title .= $title_array[$start]." ";
									}
									echo trim($dispay_title)."...";
									
								} else {
									echo $title_data;
								}
								?>
								
								
							</a>
						</h2>
						<p>
											
							<?php 
							$content_data = $item->post_content;
							echo content_data($content_data,300)."...";
							?>
							
						</p>
						<p class="right">
							<a href="<?php echo get_permalink( $item->ID ); ?>">read more</a>
						</p>
					</div>
				
				</div>
				
			</div>
		</div>

	<?php	
	}
	?>

</div>

<div>
	<input type="hidden" id="startId" name="startId" value="<?php echo $limits; ?>" />
	<input type="hidden" id="limit" name="limit" value="<?php echo $max; ?>" />
	
	<?php echo pagination_data($totalposts,$p,$lpm1,$prev,$next,$url); ?>
</div>
