<?php

/*

 * template name: Portfolio

 */
?>
<?php
get_header();

?>
 <script type="text/javascript">
$(function () {
    var tabContainers = $('div.tabs > div');
    
    $('div.tabs ul.tabNavigation a').click(function () {
        tabContainers.hide().filter(this.hash).show();
        
        $('div.tabs ul.tabNavigation a').removeClass('selected');
        $(this).addClass('selected');
        
        return false;
    }).filter(':first').click();
}); </script>

<?php
	

$fields = array(); 

 $args = array(
	'type'                     => 'post',
	'child_of'                 => 0,
	'parent'                   => '',
	'orderby'                  => 'name',
	'order'                    => 'ASC',
	'hide_empty'               => 1,
	'hierarchical'             => 1,
	'exclude'                  => '',
	'include'                  => '',
	'number'                   => '',
	'taxonomy'                 => 'catalog',
	'pad_counts'               => false );


 $categories = get_categories( $args ); 
//echo "<pre>";print_r($categories);
?>
<div class="tabs">
<ul class="tabNavigation">
 <li><a id="all" href="#taball">All</a></li>
<?php
  foreach($categories as $category) { ?>
    <li><a id="<?php  echo $category->cat_ID; ?>" href="#tab<?php echo $category->name; ?>"><?php echo $category->name;?> </a></li> 
<?php

$fields[]=$category->cat_ID;
 }?>
</ul>
<!-- Tab display end -->





  <!-- tab aLL containers -->
  <div id="taball">
    <?php   $dtable= implode(",", $fields);

 $max = 2;
     if(isset($_GET['pg'])) {
	   $p = $_GET['pg'];
	
       } else {
	
	$p = 1;	
     }

$limit = ($p - 1) * $max;
$prev = $p - 1;
$next = $p + 1;
$limits = (int)($p - 1) * $max;
    
 $totalres = count($wpdb->get_results("select po.* from $wpdb->posts po inner join $wpdb->term_relationships wtr on po.Id= wtr.object_id inner join $wpdb->term_taxonomy wtt on wtr.term_taxonomy_id = wtt.term_taxonomy_id inner join wp_terms wt on wtt.term_id = wt.term_id where wt.term_id = '$dtable' order by po.ID DESC "));

$totalposts = ceil($totalres / $max);
$lpm1 = $totalposts - 1;
if(isset($_post['cat_type'])) {
	$url = site_url().'/?page_id=143&cat_type='.$dtable;
} else {
	$url = site_url().'/?page_id=143';
}

$qw = $wpdb->get_results("select po.* from $wpdb->posts po inner join $wpdb->term_relationships wtr on po.Id= wtr.object_id inner join $wpdb->term_taxonomy wtt on wtr.term_taxonomy_id = wtt.term_taxonomy_id inner join wp_terms wt on wtt.term_id = wt.term_id where wt.term_id = '$dtable' order by po.ID DESC limit $limits,$max");

    	
   foreach($qw as $qw_id) {
    echo $qw_id->post_title;
    }

?>
<div style="text-align:center;">
<?php 
echo pagination_data($totalposts,$p,$lpm1,$prev,$next,$url); 
?>
</div>
<?php
?>
</div>
<!-- aLL END -->






 <?php foreach($categories as $category1) { ?>
 <div id="tab<?php echo $category1->name;?>">
 <?php  $catid=$category1->cat_ID; $page = (get_query_var('paged')) ? get_query_var('paged') : 1;
  $args = array('cat' =>$catid,'posts_per_page' => 3,'paged' => $page); 
  $max = 1;
     if(isset($_GET['pg'])) {
	   $p = $_GET['pg'];
	
       } else {
	
	$p = 1;	
     }

$limit = ($p - 1) * $max;
$prev = $p - 1;
$next = $p + 1;
$limits = (int)($p - 1) * $max;

echo $totalres = count($wpdb->get_results("select po.* from $wpdb->posts po inner join $wpdb->term_relationships wtr on po.Id= wtr.object_id inner join $wpdb->term_taxonomy wtt on wtr.term_taxonomy_id = wtt.term_taxonomy_id inner join wp_terms wt on wtt.term_id = wt.term_id where wt.term_id = '$catid' order by po.ID DESC "));

//devide it with the max value & round it up
$totalposts = ceil($totalres / $max);
$lpm1 = $totalposts - 1;
$url = site_url().'/?page_id=143&cat_type='.$catid;

$qw = $wpdb->get_results("select po.* from $wpdb->posts po inner join $wpdb->term_relationships wtr on po.Id= wtr.object_id inner join $wpdb->term_taxonomy wtt on wtr.term_taxonomy_id = wtt.term_taxonomy_id inner join wp_terms wt on wtt.term_id = wt.term_id where wt.term_id = '$catid' order by po.ID DESC limit $limits,$max");

    	
   foreach($qw as $qw_id) {
    echo $qw_id->post_title;
    }
 ?>
<div style="text-align:center;">
<?php //cat
 //pagination();
echo pagination_data($totalposts,$p,$lpm1,$prev,$next,$url); 
?>
</div>
</div>
<?php }
?>


<?php

  get_footer();

function pagination_data($totalposts,$p,$lpm1,$prev,$next,$url){
echo $totalposts;
    $adjacents = 3;
    if($totalposts > 1)
    {
        $pagination .= "<center><div class=\"paging\">";
        //previous button
        if ($p > 1)
        $pagination.= "<a href=\"$url&pg=$prev\"><< Previous</a> ";
        else
        $pagination.= "<span class=\"disabled\"><< Previous</span> ";
        if ($totalposts < 7 + ($adjacents * 2)){
            for ($counter = 1; $counter <= $totalposts; $counter++){
                if ($counter == $p)
                $pagination.= "<span class=\"current\">$counter</span>";
                else
                $pagination.= " <a href=\"$url&pg=$counter\">$counter</a> ";}
        }elseif($totalposts > 5 + ($adjacents * 2)){
            if($p < 1 + ($adjacents * 2)){
                for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++){
                    if ($counter == $p)
                    $pagination.= " <span class=\"current\">$counter</span> ";
                    else
                    $pagination.= " <a href=\"$url&pg=$counter\">$counter</a> ";
                }
                $pagination.= " ... ";
                $pagination.= " <a href=\"$url&pg=$lpm1\">$lpm1</a> ";
                $pagination.= " <a href=\"$url&pg=$totalposts\">$totalposts</a> ";
            }
            //in middle; hide some front and some back
            elseif($totalposts - ($adjacents * 2) > $p && $p > ($adjacents * 2)){
                $pagination.= " <a href=\"$url&pg=1\">1</a> ";
                $pagination.= " <a href=\"$url&pg=2\">2</a> ";
                $pagination.= " ... ";
                for ($counter = $p - $adjacents; $counter <= $p + $adjacents; $counter++){
                    if ($counter == $p)
                    $pagination.= " <span class=\"current\">$counter</span> ";
                    else
                    $pagination.= " <a href=\"$url&pg=$counter\">$counter</a> ";
                }
                $pagination.= " ... ";
                $pagination.= " <a href=\"$url&pg=$lpm1\">$lpm1</a> ";
                $pagination.= " <a href=\"$url&pg=$totalposts\">$totalposts</a> ";
            }else{
                $pagination.= " <a href=\"$url&pg=1\">1</a> ";
                $pagination.= " <a href=\"$url&pg=2\">2</a> ";
                $pagination.= " ... ";
                for ($counter = $totalposts - (2 + ($adjacents * 2)); $counter <= $totalposts; $counter++){
                    if ($counter == $p)
                    $pagination.= " <span class=\"current\">$counter</span> ";
                    else
                    $pagination.= " <a href=\"$url&pg=$counter\">$counter</a> ";
                }
            }
        }
        if ($p < $counter - 1)
        $pagination.= " <a href=\"$url&pg=$next\">Next >></a>";
        else
        $pagination.= " <span class=\"disabled\">Next >></span>";
        $pagination.= "</center>\n";
    }
    return $pagination;
}
 if(isset($_GET['cat_type'])) {
		if($_GET['cat_type'] == '30' || $_GET['cat_type'] == '31') { ?>
			
		<script type="text/javascript">
			
			$(function () {
				var id = '<?php echo $_GET["cat_type"] ; ?>';
			    $("#"+id).trigger('click');
			  }); 
		</script>			
	<?php	} 

	} else { ?>
		<script type="text/javascript">
			
			$(function () {
				
			    $("#all").trigger('click');
			  }); 
		</script>	
	<?php }

?>


